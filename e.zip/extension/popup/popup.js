const answer = document.getElementById("answer")

chrome.storage.sync.get(["value"], ({value}) => {
    answer.innerHTML = value
})