chrome.contextMenus.onClicked.addListener(genericOnClick);

async function genericOnClick(info, tab) {
    fetch(`http://116.203.222.184:4321/search/?data=${info.selectionText.trim()}`)
        .then(res => res.json())
        .then(data => {
            chrome.storage.sync.set({value: data})
        })
}

chrome.runtime.onInstalled.addListener(function () {
    let contexts = [
        'selection',
    ];

    let context = 'selection';
    let title = "Search";
    chrome.contextMenus.create({
        title: title,
        contexts: ['selection'],
        id: context
    });

    let parent = chrome.contextMenus.create({
        title: 'Test parent item',
        id: 'parent'
    });

    chrome.contextMenus.create({
        title: 'Child 1',
        parentId: parent,
        id: 'child1'
    });

    chrome.contextMenus.create({
        title: 'Child 2',
        parentId: parent,
        id: 'child2'
    });

    chrome.contextMenus.create({
        title: 'radio',
        type: 'radio',
        id: 'radio'
    });

    chrome.contextMenus.create({
        title: 'checkbox',
        type: 'checkbox',
        id: 'checkbox'
    });

    chrome.contextMenus.create(
        {title: 'Oops', parentId: 999, id: 'errorItem'},
        function () {
            if (chrome.runtime.lastError) {
                console.log('Got expected error: ' + chrome.runtime.lastError.message);
            }
        }
    );
});